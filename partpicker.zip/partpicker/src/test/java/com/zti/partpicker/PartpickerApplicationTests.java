package com.zti.partpicker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PartpickerApplicationTests {

	@Test
	void contextLoads() {
	}

}
