package com.zti.partpicker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartpickerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PartpickerApplication.class, args);
	}

}
